# ------------------------------------------------------------------------------
#  Copyright (c) 2022 Dimitri Kroon
#
#  SPDX-License-Identifier: GPL-3.0-or-later
#  This file is part of plugin.video.cinetree
# ------------------------------------------------------------------------------

